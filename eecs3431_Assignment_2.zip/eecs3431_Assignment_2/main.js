

var canvas;
var gl;

var ProgramObj1 = {};
var ProgramObj2 = {};
var programObj; // the current program object
var program; //the current program ID

var near = -100;
var far = 100;

var left = -3.0;
var right = 3.0;
var ytop = 3.0;
var bottom = -3.0;

var lightPosition2 = vec4(100.0, 100.0, 100.0, 1.0);
var lightPosition = vec4(0.0, 0.0, 0.0, 1.0); // with respect to the camera

var lightAmbient = vec4(1.0, 1.0, 1.0, 1.0);
var lightDiffuse = vec4(1.0, 1.0, 1.0, 1.0);
var lightSpecular = vec4(1.0, 1.0, 1.0, 1.0);

var materialAmbient = vec4(0.1, 0.1, 0.1, 1.0);
var materialDiffuse = vec4(0.5, 0.3, 0.5, 1.0);
var materialSpecular = vec4(0.4, 0.4, 0.4, 1.0);
var materialShininess = 100.0;

var modelMatrix, viewMatrix;
var modelViewMatrix, projectionMatrix, normalMatrix;
var modelViewMatrixLoc, projectionMatrixLoc, normalMatrixLoc;
var eye;
var at = vec3(0.0, 0.0, 0.0);
var up = vec3(0.0, 1.0, 0.0);

var RX = 0;
var RY = 0;
var RZ = 0;

var MS = []; // The modeling matrix stack
var TIME = 0.0; // Realtime
var TIME = 0.0; // Realtime
var resetTimerFlag = true;
var animFlag = false;
var prevTime = 0.0;
var useTextures = 0;

// ------------ Images for textures stuff --------------
var texSize = 64;

var image1 = new Array()
	for (var i = 0; i < texSize; i++)
		image1[i] = new Array();
	for (var i = 0; i < texSize; i++)
		for (var j = 0; j < texSize; j++)
			image1[i][j] = new Float32Array(4);
	for (var i = 0; i < texSize; i++)
		for (var j = 0; j < texSize; j++) {
			var c = (((i & 0x8) == 0) ^ ((j & 0x8) == 0));
			image1[i][j] = [c, c, c, 1];
		}

	// Convert floats to ubytes for texture

	var image2 = new Uint8Array(4 * texSize * texSize);

for (var i = 0; i < texSize; i++)
	for (var j = 0; j < texSize; j++)
		for (var k = 0; k < 4; k++)
			image2[4 * texSize * i + 4 * j + k] = 255 * image1[i][j][k];

var textureArray = [];

function isLoaded(im) {
	if (im.complete) {
		//    console.log("loaded") ;
		return true;
	} else {
		//    console.log("still not loaded!!!!") ;
		return false;
	}
}

function loadFileTexture(tex, filename) {
	tex.textureWebGL = gl.createTexture();
	tex.image = new Image();
	tex.image.src = filename;
	tex.isTextureReady = false;
	tex.image.onload = function () {
		handleTextureLoaded(tex);
	}
	// The image is going to be loaded asyncronously (lazy) which could be
	// after the program continues to the next functions. OUCH!
}

function loadImageTexture(tex, image) {
	tex.textureWebGL = gl.createTexture();
	tex.image = new Image();
	//tex.image.src = "CheckerBoard-from-Memory" ;

	gl.bindTexture(gl.TEXTURE_2D, tex.textureWebGL);
	//gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
	gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, texSize, texSize, 0,
		gl.RGBA, gl.UNSIGNED_BYTE, image);
	gl.generateMipmap(gl.TEXTURE_2D);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER,
		gl.NEAREST_MIPMAP_LINEAR);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); //Prevents s-coordinate wrapping (repeating)
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); //Prevents t-coordinate wrapping (repeating)
	gl.bindTexture(gl.TEXTURE_2D, null);

	tex.isTextureReady = true;

}

function initTextures() {

	textureArray.push({});
	loadFileTexture(textureArray[textureArray.length - 1], "grass.jpg");

	textureArray.push({});
	loadFileTexture(textureArray[textureArray.length - 1], "grass.jpg");

	textureArray.push({});
	loadImageTexture(textureArray[textureArray.length - 1], "grass.jpg");

}

function handleTextureLoaded(textureObj) {
	gl.bindTexture(gl.TEXTURE_2D, textureObj.textureWebGL);
	gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true); // otherwise the image would be flipped upsdide down
	gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, textureObj.image);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_NEAREST);
	gl.generateMipmap(gl.TEXTURE_2D);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); //Prevents s-coordinate wrapping (repeating)
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); //Prevents t-coordinate wrapping (repeating)
	gl.bindTexture(gl.TEXTURE_2D, null);
	//    console.log(textureObj.image.src) ;

	textureObj.isTextureReady = true;
}

//----------------------------------------------------------------

function setColor(c) {
	ambientProduct = scalev(0.7, mult(lightAmbient, c));
	ambientProduct[3] = 1.0;
	diffuseProduct = mult(lightDiffuse, c);
	specularProduct = mult(lightSpecular, materialSpecular);

	gl.uniform4fv(gl.getUniformLocation(program,
			"ambientProduct"), flatten(ambientProduct));
	gl.uniform4fv(gl.getUniformLocation(program,
			"diffuseProduct"), flatten(diffuseProduct));
	gl.uniform4fv(gl.getUniformLocation(program,
			"specularProduct"), flatten(specularProduct));
	gl.uniform4fv(gl.getUniformLocation(program,
			"lightPosition"), flatten(lightPosition));
	gl.uniform1f(gl.getUniformLocation(program,
			"shininess"), materialShininess);
}

function toggleTextures() {
	useTextures = 1 - useTextures;
	gl.uniform1i(gl.getUniformLocation(program,
			"useTextures"), useTextures);
}

function waitForTextures1(tex) {
	setTimeout(function () {
		//    console.log("Waiting for: "+ tex.image.src) ;
		wtime = (new Date()).getTime();
		if (!tex.isTextureReady) {
			//      console.log(wtime + " not ready yet") ;
			waitForTextures1(tex);
		} else {
			//      console.log("ready to render") ;
			window.requestAnimFrame(render);
		}
	}, 5);

}

// Takes an array of textures and calls render if the textures are created
function waitForTextures(texs) {
	setTimeout(function () {
		var n = 0;
		for (var i = 0; i < texs.length; i++) {
			//                    console.log("boo"+texs[i].image.src) ;
			n = n + texs[i].isTextureReady;
		}
		wtime = (new Date()).getTime();
		if (n != texs.length) {
			//             console.log(wtime + " not ready yet") ;
			waitForTextures(texs);
		} else {
			//           console.log("ready to render") ;
			window.requestAnimFrame(render);
		}
	}, 5);

}

// set uniforms that never change during execution and init others
setUniformsOnce = function (program) {

	gl.activeTexture(gl.TEXTURE0);
	gl.bindTexture(gl.TEXTURE_2D, textureArray[0].textureWebGL);
	gl.uniform1i(gl.getUniformLocation(program, "texture1"), 0);

	gl.activeTexture(gl.TEXTURE1);
	gl.bindTexture(gl.TEXTURE_2D, textureArray[0].textureWebGL);
	gl.uniform1i(gl.getUniformLocation(program, "texture2"), 0);

	gl.activeTexture(gl.TEXTURE2);
	gl.bindTexture(gl.TEXTURE_2D, textureArray[2].textureWebGL);
	gl.uniform1i(gl.getUniformLocation(program, "texture3"), 2);

	// set a default material
	setColor(materialDiffuse);
	gl.uniform1i(gl.getUniformLocation(program, "useTextures"), useTextures);
}

// set uniform locations that may change per render call
setUniformLocations = function (programObj) {
	programObj.useTexturesLoc = gl.getUniformLocation(programObj.program, "useTextures");

	// record the locations of the matrices that are used in the shaders
	programObj.modelViewMatrixLoc = gl.getUniformLocation(programObj.program, "modelViewMatrix");
	programObj.normalMatrixLoc = gl.getUniformLocation(programObj.program, "normalMatrix");
	programObj.projectionMatrixLoc = gl.getUniformLocation(programObj.program, "projectionMatrix");
}

setUniforms = function (programObj) {
	gl.uniform1i(programObj.useTexturesLoc, useTextures);
	// send all the matrices to current program
	setAllMatrices();

}

window.onload = function init() {

	canvas = document.getElementById("gl-canvas");

	gl = WebGLUtils.setupWebGL(canvas);
	if (!gl) {
		alert("WebGL isn't available");
	}

	gl.viewport(0, 0, canvas.width, canvas.height);
	gl.clearColor(0.5, 0.5, 1.0, 1.0);

	gl.enable(gl.DEPTH_TEST);

	//
	//  Load shaders and initialize attribute buffers
	//
	ProgramObj1.program = initShaders(gl, "vertex-shader", "fragment-shader");
	gl.useProgram(ProgramObj1.program);
	program = ProgramObj1.program;

	ProgramObj2.program = initShaders(gl, "vertex-shader-perPixel", "fragment-shader-perPixel");
	gl.useProgram(ProgramObj2.program);
	program = ProgramObj2.program;

	//console.log("----------------") ;
	console.log(program);

	// Load canonical objects and their attributes
	Cube.init(ProgramObj1.program);
	Cylinder.init(9, ProgramObj1.program);
	Cone.init(9, ProgramObj1.program);
	Sphere.init(20, ProgramObj1.program);

	// set the callbacks for the UI elements
	document.getElementById("sliderXi").onchange = function () {
		RX = this.value;
		window.requestAnimFrame(render);
	};
	document.getElementById("sliderYi").onchange = function () {
		RY = this.value;
		window.requestAnimFrame(render);
	};
	document.getElementById("sliderZi").onchange = function () {
		RZ = this.value;
		window.requestAnimFrame(render);
	};

	document.getElementById("animToggleButton").onclick = function () {
		if (animFlag) {
			animFlag = false;
		} else {
			animFlag = true;
			resetTimerFlag = true;
			window.requestAnimFrame(render);
		}
	};

	document.getElementById("textureToggleButton").onclick = function () {

		window.requestAnimFrame(render);
	};

	var controller = new CameraController(canvas);
	controller.onchange = function (xRot, yRot) {
		RX = xRot;
		RY = yRot;
		window.requestAnimFrame(render);
	};

	// load and initialize the textures
	initTextures();

	// Recursive wait for the textures to load
	waitForTextures(textureArray);
	//setTimeout (render, 100) ;

	myUseProgramObj(ProgramObj1);
	setUniformsOnce(ProgramObj1.program);
	setUniformLocations(ProgramObj1);
	myUseProgramObj(ProgramObj2)
	setUniformsOnce(ProgramObj2.program);
	setUniformLocations(ProgramObj2);

}

// Sets the modelview and normal matrix in the shaders
function setMV() {
	modelViewMatrix = mult(viewMatrix, modelMatrix);
	gl.uniformMatrix4fv(programObj.modelViewMatrixLoc, false, flatten(modelViewMatrix));
	normalMatrix = inverseTranspose(modelViewMatrix);
	gl.uniformMatrix4fv(programObj.normalMatrixLoc, false, flatten(normalMatrix));
}

// Sets the projection, modelview and normal matrix in the shaders
function setAllMatrices() {
	gl.uniformMatrix4fv(programObj.projectionMatrixLoc, false, flatten(projectionMatrix));
	setMV();

}

// Draws a 2x2x2 cube center at the origin
// Sets the modelview matrix and the normal matrix of the global program
function drawCube() {
	setMV();
	Cube.draw();
}

// Draws a sphere centered at the origin of radius 1.0.
// Sets the modelview matrix and the normal matrix of the global program
function drawSphere() {
	setMV();
	Sphere.draw();
}
// Draws a cylinder along z of height 1 centered at the origin
// and radius 0.5.
// Sets the modelview matrix and the normal matrix of the global program
function drawCylinder() {
	setMV();
	Cylinder.draw();
}
// Draws a cone along z of height 1 centered at the origin
// and base radius 1.0.
// Sets the modelview matrix and the normal matrix of the global program
function drawCone() {
	setMV();
	Cone.draw();
}

// Post multiples the modelview matrix with a translation matrix
// and replaces the modelview matrix with the result
function gTranslate(x, y, z) {
	modelMatrix = mult(modelMatrix, translate([x, y, z]));
}

// Post multiples the modelview matrix with a rotation matrix
// and replaces the modelview matrix with the result
function gRotate(theta, x, y, z) {
	modelMatrix = mult(modelMatrix, rotate(theta, [x, y, z]));
}

// Post multiples the modelview matrix with a scaling matrix
// and replaces the modelview matrix with the result
function gScale(sx, sy, sz) {
	modelMatrix = mult(modelMatrix, scale(sx, sy, sz));
}

// Pops MS and stores the result as the current modelMatrix
function gPop() {
	modelMatrix = MS.pop();
}

// pushes the current modelMatrix in the stack MS
function gPush() {
	MS.push(modelMatrix);
}

function myUseProgramObj(po) {
	gl.useProgram(po.program);
	program = po.program;
	programObj = po

}

function render() {

	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

	eye = vec3(0, 0, 10);

	eye[1] = eye[1] + 0;

	// set the projection matrix
	projectionMatrix = ortho(left, right, bottom, ytop, near, far);

	// set the camera matrix
	viewMatrix = lookAt(eye, at, up);

	// initialize the modeling matrix stack
	MS = [];
	modelMatrix = mat4();

	// apply the slider rotations
	gRotate(RZ, 0, 0, 1);
	gRotate(RY, 0, 1, 0);
	gRotate(RX, 1, 0, 0);

	// get real time
	var curTime;
	if (animFlag) {
		curTime = (new Date()).getTime() / 1000;
		if (resetTimerFlag) {
			prevTime = curTime;
			resetTimerFlag = false;
		}
		TIME = TIME + curTime - prevTime;
		prevTime = curTime;
		//  increment = increment +1;
		frameCounter++;
		if (TIME > timeV) {
			console.log(frameCounter);
			frameCounter = 0;
			timeV++;
		}
	}

	myUseProgramObj(ProgramObj1);
	setUniforms(ProgramObj1);

	createWorld();
	function createWorld() {
		if (TIME == 0) {
			timeV = 0;
			frameCounter = 0;
		}
		//starts
		if (TIME >= 0 && TIME <= 1.5) {
			groundTranslate = 0;
			leftAnkleRotate = 0;
			leftKneeRotate = 0;
			leftLegRotate = 0;
			rightAnkleRotate = 0;
			rightKneeRotate = 0;
			rightLegRotate = 0;
			leftArmRotateX = 0;
			leftArmRotateY = 0;
			leftArmRotateZ = 0;
			leftElbowX = 0;
			leftElbowY = 0;
			leftElbowZ = 0;
			rightArmRotateX = 0;
			rightArmRotateY = 0;
			rightArmRotateZ = 0;
			rightElbowX = 0;
			rightElbowY = 0;
			rightElbowZ = 0;
			bodyVertical = 0;
			bellyScale = 1;
			neckRotation = 0;
			neckRotationUD = 0;
			manMove = 0;
			gTranslate(0, -0.1, 0);
		}
		//looks around
		if (TIME > 1.5 && TIME < 6.5) {
			bellyScale = 1;
			neckRotation = -35 * Math.sin((2 * (TIME - 1.5)));
			gTranslate(0, -0.1, 0);
		}
		//belly rub
		if (TIME > 6.5 && TIME <= 9.5) {
			gTranslate(0, -0.1, 0);
			rightArmRotateX = -Math.abs(55 * Math.sin((1 * TIME)));
			rightElbowX = Math.abs(-30 * Math.sin((1 * TIME)));
			rightElbowY = -Math.abs(80 * Math.sin((1 * TIME)));
			rightElbowZ = Math.abs(40 * Math.sin((1 * TIME)));
		}
		//running man
		if (TIME > 9.5 && TIME <= 31) {
			gTranslate(0, 0.105, 0);
			rightArmRotateX = 0;
			rightElbowX = 0;
			rightElbowY = 0;
			rightElbowZ = 0;
			leftArmRotateX = 0;
			leftElbowX = 0;
			leftElbowY = 0;
			leftElbowZ = 0;
			leftAnkleRotate = -Math.abs(-15 * Math.sin(TIME));
			leftKneeRotate = Math.abs(35 * Math.sin((1 * TIME)));
			leftLegRotate = -60 * Math.sin(1 * TIME);
			rightAnkleRotate = -Math.abs(15 * Math.sin(TIME));
			rightKneeRotate = Math.abs(-35 * Math.sin((1 * TIME)));
			rightLegRotate = 60 * Math.sin(1 * TIME);
			leftArmRotateX = 35 * Math.sin(1 * TIME);
			rightArmRotateX = -35 * Math.sin(1 * TIME);
			bodyVertical = Math.min(0.1, 1.5 * TIME) * Math.sin(2 * TIME);
			bellyScale = Math.max(0, 1 - 0.03 * TIME);
		}
		function drawGround() {
			gPush(); {
				toggleTextures();
				gTranslate(0, -2.65, 0);
				gScale(15, 0.75, 15);
				setColor(vec4(0.4, 0.8, 0.2, 0.5));
				gTranslate(0, 0, groundTranslate);
				drawCube(); //ground
				gScale(15, 0.4, 15);
			}
			gPop();
		}

		if (TIME >= 0 && TIME <= 31) {
			gRotate(70, 0, 1, 0);
			drawGround();
		}
		gTranslate(0, -0.1, 0);
		//camera handled
		if (TIME <= 31 && TIME >= 9.5) {
			RY = RY + ((TIME - 9) * 0.025);
			gTranslate(0, 0, 0 + 0.08 * (TIME - 9.5))
			drawMan();
		}
		//final celebration
		if (TIME > 31) {
			RY = 0;
			leftAnkleRotate = 0;
			leftKneeRotate = 0;
			leftLegRotate = 0;
			rightAnkleRotate = 0;
			rightKneeRotate = 0;
			rightLegRotate = 0;
			leftArmRotateX = -90;
			leftArmRotateY = -Math.abs(20 * Math.sin(TIME - 31));
			leftArmRotateZ = 90;
			leftElbowX = -45;
			leftElbowY = -90;
			leftElbowZ = -Math.abs(10 * Math.sin(TIME - 31));
			rightArmRotateX = -90;
			rightArmRotateY = Math.abs(20 * Math.sin(TIME - 31));
			rightArmRotateZ = -90;
			rightElbowX = -45;
			rightElbowY = 90;
			rightElbowZ = 0;
			bodyVertical = 0;
			bellyScale = 1;
			neckRotation = 0;
			neckRotationUD = Math.abs(-35 * Math.sin(((TIME - 31))));
			drawGround();
			gTranslate(0, -0.1, 0);
			drawMan();
		}
		//running man
		if (TIME >= 0 && TIME < 9.5) {
			drawMan();
		}
		function drawMan() {
			gPush(); {
				toggleTextures();
				setColor(vec4(1.0, 0.5, 0.0, 1.0));
				gTranslate(0, 0, 0);
				gTranslate(0, bodyVertical, 0);
				gScale(0.5, 0.75, 0.2);
				drawCube(); //body
				gScale(1 / 0.5, 1 / 0.75, 1 / 0.2);
				gPush(); {
					gTranslate(-0.5, 0.6, 0);
					gScale(0.15, 0.15, 0.15);
					gRotate(rightArmRotateX, 1, 0, 0);
					gRotate(rightArmRotateY, 0, 1, 0);
					gRotate(rightArmRotateZ, 0, 0, 1);
					drawSphere(); //right arm
					gScale(1 / 0.15, 1 / 0.15, 1 / 0.15);
					gPush(); {
						gTranslate(-0.10, -0.3, 0)
						gRotate(90, 1, 0, 0);
						gRotate(-15, 0, 1, 0);
						gScale(0.25, 0.25, 0.75);
						drawCylinder();
						gScale(4, 4, 1.333)
						gRotate(35, 0, 1, 0);
						gRotate(-90, 1, 0, 0);
						gPush(); {
							gScale(0.11, 0.11, 0.11);
							gTranslate(-2.25, -3.25, 0);
							gRotate(-20, 1, 0, -1);
							gRotate(rightElbowX, 1, 0, 0);
							gRotate(rightElbowY, 0, 1, 0);
							gRotate(rightElbowZ, 0, 0, 1);
							drawSphere(); //right elbow
							gScale(1 / 0.11, 1 / 0.11, 1 / 0.11);
							gPush(); {
								gTranslate(-0.15, -0.2, 0);
								gRotate(90, 1, 0, 0);
								gRotate(-35, 0, 1, 0);
								gScale(0.2, 0.2, 0.4);
								drawCylinder();
								gScale(1 / 0.2, 1 / 0.2, 1 / 0.4);
								gRotate(35, 0, 1, 0);
								gRotate(-90, 1, 0, 0);
								gPush(); {
									gScale(0.1, 0.1, 0.1);
									gTranslate(-0.9, -1.25, 0);
									drawSphere();
									gScale(1 / 0.1, 1 / 0.1, 1 / 0.1);
									gPush(); {}
									gPop();
								}
								gPop();
							}
							gPop();
							gRotate(20, 1, 0, -1);
						}
						gPop();
					}
					gPop();
				}
				gPop();
				gPush(); {
					gTranslate(0.5, 0.6, 0);
					gScale(0.15, 0.15, 0.15);
					gRotate(leftArmRotateX, 1, 0, 0);
					gRotate(leftArmRotateY, 0, 1, 0);
					gRotate(leftArmRotateZ, 0, 0, 1);
					drawSphere(); //left arm
					gScale(1 / 0.15, 1 / 0.15, 1 / 0.15);
					gPush(); {
						gTranslate(0.10, -0.3, 0);
						gRotate(90, 1, 0, 0);
						gRotate(15, 0, 1, 0);
						gScale(0.25, 0.25, 0.75)
						drawCylinder();
						gScale(4, 4, 1.333)
						gRotate(-35, 0, 1, 0);
						gRotate(-90, 1, 0, 0);
						gPush(); {
							gScale(0.11, 0.11, 0.11);
							gTranslate(2.25, -3.25, 0);
							gRotate(-20, 1, 0, 1);
							gRotate(leftElbowX, 1, 0, 0);
							gRotate(leftElbowY, 0, 1, 0);
							gRotate(leftElbowZ, 0, 0, 1);
							drawSphere(); //left elbow
							gScale(1 / 0.11, 1 / 0.11, 1 / 0.11);
							gPush(); {
								gTranslate(0.15, -0.2, 0);
								gRotate(90, 1, 0, 0);
								gRotate(35, 0, 1, 0);
								gScale(0.2, 0.2, 0.4);
								drawCylinder();
								gScale(1 / 0.2, 1 / 0.2, 1 / 0.4);
								gRotate(35, 0, 1, 0);
								gRotate(-90, 1, 0, 0);
								gPush(); {
									gScale(0.1, 0.1, 0.1);
									gTranslate(-0.9, -1.25, 0);
									drawSphere();
									gScale(1 / 0.1, 1 / 0.1, 1 / 0.1);
									gPush(); {}
									gPop();
								}
								gPop();
							}
							gPop();
							gRotate(20, 1, 0, 1);
						}
						gPop();
					}
					gPop();
				}
				gPop();
				gPush(); {
					//leg right
					gTranslate(-0.25, -0.75, 0);
					gScale(0.2, 0.2, 0.2);
					gRotate(rightLegRotate, 1, 0, 0);
					drawSphere(); //right leg
					gScale(1 / 0.2, 1 / 0.2, 1 / 0.2);
					gPush(); {
						gScale(0.4, 0.4, 0.4);
						gRotate(90, 1, 0, 0);
						gTranslate(0, 0, 0.65);
						drawCylinder();
						gRotate(-90, 1, 0, 0);
						gScale(1 / 0.4, 1 / 0.4, 1 / 0.4);
						gPush(); {
							gScale(0.15, 0.15, 0.15);
							gTranslate(0, -1, 0);
							gRotate(rightKneeRotate, 1, 0, 0);
							drawSphere(); // right knee
							gScale(1 / 0.15, 1 / 0.15, 1 / 0.15);
							gPush(); {
								gScale(0.3, 0.5, 0.3);
								gRotate(90, 1, 0, 0);
								gTranslate(0, 0, 0.5);
								drawCylinder();
								gRotate(-90, 1, 0, 0);
								gScale(1 / 0.3, 1 / 0.5, 1 / 0.3);
								gPush(); {
									gTranslate(0, -0.25, 0);
									gScale(0.1, 0.1, 0.1);
									gRotate(rightAnkleRotate, 1, 0, 0);
									drawSphere(); //right foot
									gScale(1 / 0.1, 1 / 0.1, 1 / 0.1);
									Drawfoot();
								}
								gPop();
							}
							gPop();
						}
						gPop();
					}
					gPop();
				}
				gPop();
				gPush(); {
					//leg left
					gTranslate(0.25, -0.75, 0);
					gScale(0.2, 0.2, 0.2);
					gRotate(leftLegRotate, 1, 0, 0);
					drawSphere(); //left leg sphere
					gScale(1 / 0.2, 1 / 0.2, 1 / 0.2);
					gPush(); {
						gScale(0.4, 0.4, 0.4);
						gRotate(90, 1, 0, 0);
						gTranslate(0, 0, 0.65);
						drawCylinder();
						gRotate(-90, 1, 0, 0);
						gScale(1 / 0.4, 1 / 0.4, 1 / 0.4);
						gPush(); {
							gScale(0.15, 0.15, 0.15);
							gTranslate(0, -1, 0);
							gRotate(leftKneeRotate, 1, 0, 0);
							drawSphere(); //left knee
							gScale(1 / 0.15, 1 / 0.15, 1 / 0.15);
							gPush(); {
								gScale(0.3, 0.5, 0.3);
								gRotate(90, 1, 0, 0);
								gTranslate(0, 0, 0.5);
								drawCylinder();
								gRotate(-90, 1, 0, 0);
								gScale(1 / 0.3, 1 / 0.5, 1 / 0.3);
								gPush(); {
									gTranslate(0, -0.25, 0);
									gScale(0.1, 0.1, 0.1);
									gRotate(leftAnkleRotate, 1, 0, 0);
									drawSphere(); //left ankle
									gScale(1 / 0.1, 1 / 0.1, 1 / 0.1);
									Drawfoot();
								}
								gPop();
							}
							gPop();
						}
						gPop();
					}
					gPop();
				}
				gPop();
				gPush(); {

					gTranslate(0, 0.75, 0);
					gRotate(90, 1, 0, 0);
					gScale(0.25, 0.25, 0.25);
					gRotate(neckRotation, 0, 0, 1);
					gRotate(neckRotationUD, 1, 0, 0);
					drawCylinder(); //neck
					gScale(4, 4, 4);
					gRotate(-90, 1, 0, 0);
					gPush(); {
						gScale(0.25, 0.4, 0.25);
						gTranslate(0, 1, 0);
						drawSphere();
						gScale(1 / 0.25, 1 / 0.4, 1 / 0.25);
						gPush(); {
							gScale(0.105, 0.105, 0.105);
							gTranslate(0.75, 1.1, 1.25);
							setColor(vec4(1, 1, 1, 1));
							drawSphere();
							gPush(); {
								setColor(vec4(0, 0, 0, 1));
								gScale(0.25, 0.25, 0.25);
								gTranslate(1.75, 1, 3.25);
								drawSphere();
								gScale(1 / 0.25, 1 / 0.25, 1 / 0.25);
							}
							gPop();
							gTranslate(-0.75, -1.1, -1.25);
							gScale(1 / 0.105, 1 / 0.105, 1 / 0.105);
							gScale(0.105, 0.105, 0.105);
							gTranslate(-0.75, 1.1, 1.25);
							setColor(vec4(1, 1, 1, 1));
							drawSphere();
							gPush(); {
								setColor(vec4(0, 0, 0, 1));
								gScale(0.25, 0.25, 0.25);
								gTranslate(-1.75, 1, 3.25);
								drawSphere();
								gScale(1 / 0.25, 1 / 0.25, 1 / 0.25);
							}
							gPop();

						}
						gPop();
					}
					gPop();
				}
				gPop();
				gScale(0.50, 0.55, 0.45);
				gTranslate(0, -0.45, 0.5);
				gScale(1, 1, bellyScale);
				if (TIME <= 31) {
					setColor(vec4(1.0, 0.5, 0.0, 1.0));
					gTranslate(0, 0.1, 0);
					drawSphere(); // belly
					gTranslate(0, -0.1, 0);
					//
				}
				//draw abs for celebration
				if (TIME > 31) {
					gScale(0.35, 0.1, 0.025);
					setColor(vec4(0.54, 0.26, 0.07, 1.0));
					gTranslate(-1.255, 2, 0);
					drawCube();
					gTranslate(2.25, 0, 0);
					drawCube();
					gTranslate(0, -2.75, 0);
					drawCube();
					gTranslate(-2.25, 0, 0);
					drawCube();
					gTranslate(0, -2.75, 0);
					drawCube();
					gTranslate(2.25, 0, 0);
					drawCube();
					gScale(1 / 0.35, 1 / 0.1, 1);
					gScale(0.45, 0.45, 1);
					gTranslate(0.25, 3.25, 0); ;
					drawCube();
					gTranslate(-2.1, 0, 0);
					drawCube();
				}
			}
			gPop();
		}
	}

	myUseProgramObj(ProgramObj2);
	// send all the matrices to the current program
	setUniforms(ProgramObj2);

	//    gPush() ;
	//  {
	//      gTranslate(1,0,0) ;
	// setColor(vec4(1.0,1.0,0.0,1.0)) ;
	//      gRotate(TIME*180/3.14159,0,1,0) ;
	//      drawSphere() ;
	//  }
	//  gPop() ;

	if (animFlag)
		window.requestAnimFrame(render);
}
function Drawfoot() {
	gPush(); {
		gScale(0.1, 0.05, 0.2);
		gTranslate(0, -1.5, 0.6);
		drawCube();
	}
	gPop();
}
// A simple camera controller which uses an HTML element as the event
// source for constructing a view matrix. Assign an "onchange"
// function to the controller as follows to receive the updated X and
// Y angles for the camera:
//
//   var controller = new CameraController(canvas);
//   controller.onchange = function(xRot, yRot) { ... };
//
// The view matrix is computed elsewhere.
function CameraController(element) {
	var controller = this;
	this.onchange = null;
	this.xRot = 0;
	this.yRot = 0;
	this.scaleFactor = 3.0;
	this.dragging = false;
	this.curX = 0;
	this.curY = 0;

	// Assign a mouse down handler to the HTML element.
	element.onmousedown = function (ev) {
		controller.dragging = true;
		controller.curX = ev.clientX;
		controller.curY = ev.clientY;
	};

	// Assign a mouse up handler to the HTML element.
	element.onmouseup = function (ev) {
		controller.dragging = false;
	};

	// Assign a mouse move handler to the HTML element.
	element.onmousemove = function (ev) {
		if (controller.dragging) {
			// Determine how far we have moved since the last mouse move
			// event.
			var curX = ev.clientX;
			var curY = ev.clientY;
			var deltaX = (controller.curX - curX) / controller.scaleFactor;
			var deltaY = (controller.curY - curY) / controller.scaleFactor;
			controller.curX = curX;
			controller.curY = curY;
			// Update the X and Y rotation angles based on the mouse motion.
			controller.yRot = (controller.yRot + deltaX) % 360;
			controller.xRot = (controller.xRot + deltaY);
			// Clamp the X rotation to prevent the camera from going upside
			// down.
			if (controller.xRot < -90) {
				controller.xRot = -90;
			} else if (controller.xRot > 90) {
				controller.xRot = 90;
			}
			// Send the onchange event to any listener.
			if (controller.onchange != null) {
				controller.onchange(controller.xRot, controller.yRot);
			}
		}
	};
}
