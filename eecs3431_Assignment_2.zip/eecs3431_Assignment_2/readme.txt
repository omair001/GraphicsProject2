///////////////////////////////////SYED ANWAR README/////////////////////////////////

I have attempted to implement all parts of the assignment.
I have a multi hierarchical object and the ground has texture. 
The camera moves around and rotates the entire scene and the man runs. the final scene is him celebrating.
This project relies on the time to do all the rotations and the frame rate is displayed in the console.
A movie of this program is also attached. The scene did not work for me on Google chrome and I believe this may
be because of the security reasons